## 鹤形-部件字根

![img](bujian.assets/hebu.png)

记忆方法如下：

![img](bujian.assets/bujm.png)

## 墨奇音形-部件字根

![墨奇字根](bujian.assets/moqi-zigen.png)
